DROP TABLE IF EXISTS students;
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT ,
    name TEXT,
    age INTEGER,
    phone TEXT,
    email TEXT
);




