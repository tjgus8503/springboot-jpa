package com.example.http;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpApplicationTests {

	@Test
	void contextLoads() {
	}

}
