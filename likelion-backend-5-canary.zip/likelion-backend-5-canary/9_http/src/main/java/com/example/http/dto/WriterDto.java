package com.example.http.dto;

import lombok.Data;

@Data
public class WriterDto {
    private String name;
    private Integer age;
    private String address;
}
