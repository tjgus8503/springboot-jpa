package com.example.student;

import org.springframework.stereotype.Service;


@Service
public class StudentService {
    public StudentService() {}

    // CREATE
    public void createStudent() {}

    // READ
    public void readStudent() {}

    // READ ALL
    public void readStudentAll() {}

    // UPDATE
    public void updateStudent() {}

    // DELETE
    public void deleteStudent() {}
}
