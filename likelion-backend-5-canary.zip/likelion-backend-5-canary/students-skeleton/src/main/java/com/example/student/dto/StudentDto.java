package com.example.student.dto;

public class StudentDto {
}
