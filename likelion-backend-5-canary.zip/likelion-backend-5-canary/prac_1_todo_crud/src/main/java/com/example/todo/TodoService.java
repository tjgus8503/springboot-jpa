package com.example.todo;

import org.springframework.stereotype.Service;

@Service
public class TodoService {
    // 필요한 Service 메소드를 자유롭게 구성합니다.
}
