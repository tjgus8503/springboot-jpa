INSERT INTO users(username, email, phone, bio)
VALUES ('jeeho.dev', 'jeeho.dev@gmail.com', '010-1234-5678', 'Developer Developing Developers');

