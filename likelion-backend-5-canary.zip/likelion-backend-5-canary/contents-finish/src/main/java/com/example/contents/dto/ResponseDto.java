package com.example.contents.dto;

import lombok.Data;

@Data
public class ResponseDto {
    private String message;
}
