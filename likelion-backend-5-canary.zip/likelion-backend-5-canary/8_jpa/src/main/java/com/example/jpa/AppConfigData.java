package com.example.jpa;

public class AppConfigData {
    private final String connectionUrl;
    public AppConfigData(String connectionUrl){
        this.connectionUrl = connectionUrl;
    }
}
