package com.example.demo.yes.very.deep.pack;

import org.springframework.stereotype.Controller;

@Controller
public class DeepController {
}
