package com.example.demo.no;

import org.springframework.stereotype.Component;


@Component
public class NoComponent {
}
