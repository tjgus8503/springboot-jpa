package com.example.demo.yes.foo.bar.baz;

import org.springframework.stereotype.Component;


@Component
public class FooBarComponent {
}
