package com.example.demo.yes;

import org.springframework.stereotype.Component;

@Component
public class YesComponent {
}
