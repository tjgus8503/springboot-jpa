package com.example.demo.yes.very.deep.pack;


import org.springframework.stereotype.Component;

@Component
public class DeepComponent {
}
