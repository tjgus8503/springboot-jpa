package com.example.demo.temp;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.DispatcherServlet;

@Controller
public class TempController {
}
