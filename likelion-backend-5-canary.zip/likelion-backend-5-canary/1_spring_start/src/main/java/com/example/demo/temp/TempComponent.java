package com.example.demo.temp;

import org.springframework.stereotype.Component;

@Component
public class TempComponent {
}
