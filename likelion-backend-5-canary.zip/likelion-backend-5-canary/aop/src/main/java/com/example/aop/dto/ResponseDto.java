package com.example.aop.dto;

import lombok.Data;

@Data
public class ResponseDto {
    private String message;
}
